from mininet.topo import Topo
from mininet.net import Mininet
from mininet.util import irange,dumpNodeConnections
from mininet.log import setLogLevel
from mininet.node import Controller, RemoteController,OVSKernelSwitch
from functools import partial
from mininet.link import TCLink
import os
from mininet.cli import CLI
from mininet.log import setLogLevel, info

CONTROLLER_0_IP='127.0.0.1'

CONTROLLER_0_PORT=6633

class  FatTree(Topo):
	"""docstring for  FatTree"""
	def __init__(self, core):
		super( FatTree, self).__init__()

		i=1
		corerouters = {}
		for x in range(0, core):
			corerouters[x] = self.addSwitch('cr'+str(i))
			i+=1


		info('*** Adding aggregate router                       ***\n')
		aggrouters = {}
		for x in range(0,(core * 2)):
			aggrouters[x] = self.addSwitch('ar'+str(i) )
			i+=1

		info('*** Adding edge routers                          ***\n' )
		edgerouters = {}
		for x in range(0, (core *2)):
			edgerouters[x] = self.addSwitch('er'+str(i) )
			i+=1

		info('*** Adding hosts                                 ***\n' )
		hosts = {}
		for x in range(0, 2*(core *2)):
			hosts[x] = self.addHost('h'+str(x) )


		info('*** Adding links to construct topology ***\n')
		info('------------------------------------------\n')
		info('*********************************************************\n')
		info('*     cr0          cr1          cr2          cr3        *\n')
		info('*                                                       *\n')
		info('*  ar0    ar1    ar2    ar3    ar4    ar5    ar6    ar7 *\n')
		info('*                                                       *\n')
		info('*  er0    er1    er2    er3    er4    er5    er6    er7 *\n')
		info('*                                                       *\n')
		info('*********************************************************\n')

		info('*** Adding links to core routers                      ***\n')
		for x in range(0,core*2, 2):
			self.addLink(corerouters[0], aggrouters[x], bw=1000)
			self.addLink(corerouters[1], aggrouters[x], bw=1000)
			#connections between the first two core routers and the even
			#aggregate routers
			#bandwidth set to 1 Gbps
		for x in range(1, core*2, 2):
			self.addLink(corerouters[2], aggrouters[x], bw=1000)
			self.addLink(corerouters[3], aggrouters[x], bw=1000)
			#connections between the second two core routers and the odd
			#aggregate routers
			#bandwidth set to 1 Gbps
		info('*** Adding links to aggregate routers                 ***\n')
		for x in range(0, (core*2), 2):
			self.addLink(aggrouters[x], edgerouters[x], bw=100)
			self.addLink(aggrouters[x], edgerouters[x+1], bw=100)

		for x in range(1, (core*2), 2):
			self.addLink(aggrouters[x], edgerouters[x], bw=100)
			self.addLink(aggrouters[x], edgerouters[x-1], bw=100)
			#Creates a Mesh between the aggregate routers and edgerouters
			# in each pod
			#bandwidth set to 100 Mbps

		info('*** Adding links to hosts                             ***\n')
		for x in range(0, (core*2)):
			self.addLink(hosts[2*x], edgerouters[x], bw=100)
			self.addLink(hosts[2*x+1], edgerouters[x], bw=100)


def Network():
	ft = FatTree(4)
	c0 = RemoteController( 'c0', ip=CONTROLLER_0_IP, port=CONTROLLER_0_PORT)
	net = Mininet( topo=ft,switch=OVSKernelSwitch,controller=c0,link=TCLink)   
	net.start()
	CLI( net )
	net.stop()

if __name__ == '__main__':
	Network()
