# Cognitive-Routing-Engine
Applying Reinforecement Learning Algortihms to perform traffic engineering using SDN
