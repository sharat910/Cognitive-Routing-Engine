from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet,arp
from ryu.lib.packet import ether_types
from metric import NetMon
from ryu.controller import dpset
from ryu.topology.switches import Switches
import networkx as nx
import requests

class CognitiveRoutingEngine(NetMon):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    # _CONTEXTS = {'netmon': NetMon,
    #             'dpset': dpset.DPSet,
    #             'topology':Switches}
    def __init__(self, *args, **kwargs):
        super(CognitiveRoutingEngine, self).__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.arp_table = {}
        self.flow_active = {}
        self.init_req = 10
        # self.netmon = kwargs['netmon']

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def initial_flows(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        #Dropping dhcp request coz mininet already configured the hosts
        match = parser.OFPMatch(eth_type = 0x0800,ipv4_src = '0.0.0.0')
        self.drop_wala_flow(datapath,match)
        # install table-miss flow entry
        #
        # We specify NO BUFFER to max_len of the output action due to
        # OVS bug. At this moment, if we specify a lesser number, e.g.,
        # 128, OVS will send Packet-In with invalid buffer_id and
        # truncated packet data. In that case, we cannot output packets
        # correctly.  The bug has been fixed in OVS v2.1.0.
        # match = parser.OFPMatch()
        # actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
        #                                   ofproto.OFPCML_NO_BUFFER)]
        # self.add_flow(datapath, 0, match, actions)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS,
                                             actions)]
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match,
                                    instructions=inst,hard_timeout=20,
                                    flags=ofproto.OFPFF_SEND_FLOW_REM)
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, instructions=inst,hard_timeout=65,
                                    flags=ofproto.OFPFF_SEND_FLOW_REM)
        print "Adding flow to DPID: %d" % (datapath.id)
        print "Match",match
        print "Action",actions
        self.flow_active[(datapath.id,match['eth_src'],match['eth_dst'])] = 1
        datapath.send_msg(mod)

    def drop_wala_flow(self,datapath,match):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        instruction = [
            parser.OFPInstructionActions(ofproto.OFPIT_CLEAR_ACTIONS, [])
            ]
        msg = parser.OFPFlowMod(datapath=datapath,
                                priority = 1,
                                command = ofproto.OFPFC_ADD,
                                match = match,
                                instructions = instruction
                                )
        datapath.send_msg(msg)

    @set_ev_cls(ofp_event.EventOFPFlowRemoved, MAIN_DISPATCHER)
    def flow_removed_handler(self, ev):
        from pprint import pprint
        msg = ev.msg
        dp = msg.datapath
        ofp = dp.ofproto
        self.flow_active[(dp.id,msg.match['eth_src'],msg.match['eth_dst'])] = 0
        print "\nFlow removed",dp.id,msg.match


    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packetin_handler(self, ev):
        # If you hit this you might want to increase
        # the "miss_send_length" of your switch
        
        if ev.msg.msg_len < ev.msg.total_len:
            self.logger.debug("packet truncated: only %s of %s bytes",
                              ev.msg.msg_len, ev.msg.total_len)
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]
        eth_dst = eth.dst
        eth_src = eth.src

        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            # ignore lldp packet
            return

        if eth.ethertype == ether_types.ETH_TYPE_IPV6:
            print "Dropping IPv6"
            match = parser.OFPMatch(eth_type = ether_types.ETH_TYPE_IPV6)
            self.drop_wala_flow(datapath,match)
            return

        #print pkt,"\n"
        if eth.ethertype == ether_types.ETH_TYPE_ARP:
            print self.handle_arp(msg)
            return

                
        
        if eth.ethertype == ether_types.ETH_TYPE_IP:
            match = parser.OFPMatch(eth_src=eth.src,eth_dst=eth.dst)
            src_dpid = self.topology.hosts[eth_src].port.dpid
            dst_dpid = self.topology.hosts[eth_dst].port.dpid
            print "\nPacket in | A new request from DPID:",datapath.id," for %d --> %d" % (int(src_dpid),int(dst_dpid))
            shortest_path = self.paths[(datapath.id,dst_dpid)][0]
            # self.install_flows_in_path(shortest_path,match,msg)
            
            if self.flow_active.get((datapath.id,eth.src,eth.dst),None) == None:
                self.flow_active[(datapath.id,eth.src,eth.dst)] = 0

            if not self.flow_active[(datapath.id,eth.src,eth.dst)] and src_dpid == datapath.id:
                if self.init_req == 0:
                    try:
                        r = requests.get("http://192.168.0.111:5000/%d/%d" % (int(src_dpid),int(dst_dpid)),timeout=1.5)
                        path = eval(r.text)["path"]
                        if path == None:
                            path = shortest_path
                    except:
                        print "Unable to get path from RL agent"
                        path = shortest_path
                    self.install_flows_in_path(path,match,msg)
                else:
                    self.install_flows_in_path(shortest_path,match,msg)
                    self.init_req -= 1
            else:
                print "Shortest path:",shortest_path
                out_port = self.net[int(datapath.id)][shortest_path[shortest_path.index(int(datapath.id))+1]]['src_port']               
                actions = [datapath.ofproto_parser.OFPActionOutput(out_port)]
                data = msg.data
                out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                          in_port=in_port, actions=actions, data=data)
                datapath.send_msg(out)
            return
        
        print pkt
        return
        

    def install_flows_in_path(self,switch_path,match,msg):        
        print "Installing flows in Path:",switch_path
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']
        
        print match
        nodes_wo_src = switch_path[1:]
        nodes_wo_src.reverse()
        print "Intermediate nodes in reverse",nodes_wo_src[1:]
        for i in range(1,len(nodes_wo_src)):
            dp = self.dpdic[nodes_wo_src[i]]
            out_port = self.net[nodes_wo_src[i]][nodes_wo_src[i-1]]['src_port']
            actions = [dp.ofproto_parser.OFPActionOutput(out_port)]
            self.add_flow(dp, 1, match, actions)


        out_port= self.net[switch_path[0]][switch_path[1]]['src_port']
        actions = [datapath.ofproto_parser.OFPActionOutput(out_port)]
        if msg.buffer_id != ofproto.OFP_NO_BUFFER:
            self.add_flow(datapath, 1, match, actions, msg.buffer_id)
            return
        else:
            self.add_flow(datapath, 1, match, actions)
        return

    def handle_arp(self,msg):
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]
        arp_pkt = pkt.get_protocols(arp.arp)[0]
        print arp_pkt
        if arp_pkt:
            self.arp_table[arp_pkt.src_ip] = eth.src
            if arp_pkt.opcode == arp.ARP_REQUEST:
                hwtype = arp_pkt.hwtype
                proto = arp_pkt.proto
                hlen = arp_pkt.hlen
                plen = arp_pkt.plen
                arp_src_ip = arp_pkt.src_ip
                arp_dst_ip = arp_pkt.dst_ip
                if arp_dst_ip in self.arp_table:
                    actions = [parser.OFPActionOutput(in_port)]
                    ARP_Reply = packet.Packet()

                    ARP_Reply.add_protocol(ethernet.ethernet(
                        ethertype=eth.ethertype,
                        dst=eth.src,
                        src=self.arp_table[arp_dst_ip]))
                    ARP_Reply.add_protocol(arp.arp(
                        opcode=arp.ARP_REPLY,
                        src_mac=self.arp_table[arp_dst_ip],
                        src_ip=arp_dst_ip,
                        dst_mac=eth.src,
                        dst_ip=arp_src_ip))

                    ARP_Reply.serialize()

                    out = parser.OFPPacketOut(
                        datapath=datapath,
                        buffer_id=ofproto.OFP_NO_BUFFER,
                        in_port=ofproto.OFPP_CONTROLLER,
                        actions=actions, data=ARP_Reply.data)
                    datapath.send_msg(out)
                    print "ARP_Reply"
                    return True