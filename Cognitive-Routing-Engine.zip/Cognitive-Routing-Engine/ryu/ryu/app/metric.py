from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, DEAD_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ether_types
from ryu.lib import hub
from ryu.controller import dpset
from ryu.lib import dpid as dpid_lib
from ryu.lib import ofctl_v1_3
from ryu.topology.switches import Switches
from ryu.topology.api import get_switch, get_link
from ryu.app.wsgi import ControllerBase
from ryu.topology import event, switches
import requests
import networkx as nx
import itertools
import time
import socket               
import os
import cPickle

class NetMon(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {'dpset': dpset.DPSet,                 
                 'topology':Switches}
 
    def __init__(self, *args, **kwargs):
        super(NetMon, self).__init__(*args, **kwargs)
        self.net=nx.DiGraph()
        self.topology = kwargs['topology']
        self.dpset = kwargs['dpset']
        self.switch_data = {}
        self.bw_time_interval = 1
        self.port_macs = {}
        self.host_macs = {}
        self.dpdic = {}
        self.paths = {}
        self.RTT = {}
        self.start_time = {}
        self.tx_dict = {}
        self.dplock={}
        self.port_data = {}
        self.datapath_RTT_thread = hub.spawn(self._get_datapath_RTT)
        self.link_delay_thread = hub.spawn(self.update_graph_delay)
        self.link_bw_thread = hub.spawn(self.update_graph_bandwidth)
  
    # Handy function that lists all attributes in the given object
    def ls(self,obj):
        print("\n".join([x for x in dir(obj) if x[0] != "_"]))
 
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures , CONFIG_DISPATCHER)
    def switch_features_handler(self , ev):
        print "switch_features_handler is called"
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER)]
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS , actions)]
        mod = datapath.ofproto_parser.OFPFlowMod(
        datapath=datapath, match=match, cookie=0,
        command=ofproto.OFPFC_ADD, idle_timeout=0, hard_timeout=0, priority=0, instructions=inst)
        datapath.send_msg(mod)
    
    @set_ev_cls(ofp_event.EventOFPStateChange,[MAIN_DISPATCHER, DEAD_DISPATCHER])
    def dispacher_change(self, ev):
        assert ev.datapath is not None
        dp = ev.datapath
        if dp.id is None:
            return
        if ev.state == MAIN_DISPATCHER:
            self.dpdic[dp.id] = dp
            self.RTT[dp.id] = 0
            self.start_time[dp.id] = 0
            self.tx_dict[dp.id] = {}
            self.port_data[dp.id] = []
            msg = 'Join SW.'
        elif ev.state == DEAD_DISPATCHER:
            ret = self.dpdic.pop(dp.id, None)
            if ret is None:
                msg = 'Leave unknown SW.'
            else:
                msg = 'Leave SW.'
        self.logger.info('dpid=%s : %s %s', dpid_lib.dpid_to_str(dp.id), msg, self.dpdic)

    def add_flow_to_dpid(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS,
                                             actions)]
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match,
                                    instructions=inst)
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']
 
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)

        dst = eth.dst
        src = eth.src
        dpid = datapath.id
        
        if not eth.ethertype == ether_types.ETH_TYPE_LLDP:         
            #self.logger.info("packet in %s %s %s %s", dpid, src, dst, in_port)
            pass
        else:
            return

        #Add to graph
        if src not in self.net and src not in self.port_macs.keys():
            print "Adding new node",src,"to",str(dpid)
            self.host_macs[src] = {'dpid':dpid,'port_no':in_port}
            self.net.add_node(src)
            self.net.add_edge(dpid,src,{'port':in_port})
            self.net.add_edge(src,dpid)
            #Adding flow in datapath to forward traffic to host
            match = parser.OFPMatch(eth_dst=src)
            actions = [parser.OFPActionOutput(in_port)]
            self.add_flow_to_dpid(datapath,1,match,actions)

        return
   
    @set_ev_cls(event.EventSwitchEnter)
    def get_switch_data(self, ev):    
        switch = ev.switch
        print type(switch.dp.id)           
        self.net.add_node(switch.dp.id)
        datapath = switch.dp
        dpid = datapath.id
        ports = self.dpset.get_ports(int(dpid))
        self.switch_data[dpid] = {}
        for port in ports:
            self.switch_data[dpid][port.port_no] = port.hw_addr
            self.port_macs[port.hw_addr] = {'dpid':dpid,'port_no':port.port_no}
        print "\n**********Added Switch:",switch

    @set_ev_cls(event.EventLinkAdd)
    def get_link_data(self,ev):
        link = ev.link
        link_info = (link.src.dpid,link.dst.dpid,{'src_port':link.src.port_no,'dst_port':link.dst.port_no})
        self.net.add_edge(*link_info)
        print "\n**********Added link:",link_info


    @set_ev_cls(event.EventHostAdd)
    def get_host_data(self,ev):
        print "\n**********Added Host:",ev.host


    def _send_echo_request(self):
        for datapath in self.dpdic.values():
            parser = datapath.ofproto_parser
            echo_req = parser.OFPEchoRequest(datapath,
                                             data="%.12f" % time.time())
            datapath.send_msg(echo_req)
            # Important! Don't send echo request together, Because it will
            # generate a lot of echo reply almost in the same time.
            # which will generate a lot of delay of waiting in queue
            # when processing echo reply in echo_reply_handler.

            hub.sleep(0.05)

    @set_ev_cls(ofp_event.EventOFPEchoReply, MAIN_DISPATCHER)
    def echo_reply_handler(self, ev):
        recv_timestamp = time.time()
        try:
            latency = recv_timestamp - eval(ev.msg.data)
            self.RTT[ev.msg.datapath.id] = latency
        except:
            return

    def _get_datapath_RTT(self):
        self.precompute_paths()
        hub.sleep(5)        
        while True:
            #print "Getting RTT"
            self._send_echo_request()
            hub.sleep(2)   

    def precompute_paths(self):
        if os.path.isfile("paths.pkl"):
            self.paths = cPickle.load(open("paths.pkl",'rb'))
            return
        print "Precomputing Paths"
        dps = filter(lambda x: isinstance(x,int),self.net.nodes())
        src_dst_pairs = [pair for pair in itertools.product(dps, repeat=2) if pair[0] != pair[1]]
        for pair in src_dst_pairs:
            self.paths[pair]=sorted(list(nx.all_simple_paths(self.net, source=pair[0], target=pair[1])),key=len)
        with open("paths.pkl",'wb') as f:
            cPickle.dump(self.paths,f)

    def update_graph_delay(self):
        hub.sleep(10)
        print "Delay Data Gathering Started"  
        while True:              
            #print "Updating graph edge weights"
            delay_dict = {}
            links_list = self.topology.links
            all_ports = self.topology.ports
            for link in links_list:
                src_port = link.src
                dst_port = link.dst
                lldp_delay = all_ports[src_port].delay
                link_delay = self.calc_link_delay(src_port.dpid,dst_port.dpid,lldp_delay)
                link_delay = max(0,link_delay)
                #Set delay property of link
                link.delay = link_delay
                delay_dict[(src_port.dpid,dst_port.dpid)] = link_delay
                ## Update Graph weight
                self.net[src_port.dpid][dst_port.dpid]['delay'] = link_delay
            
            #self.dlclient.send(" d" + str(delay_dict))
            try:
                requests.put("http://192.168.0.111:5000/dl",data={"dl":str(delay_dict)})
            except:
                print "Error in dl"
                pass
            hub.sleep(1)

    def calc_link_delay(self,src_dpid,dst_dpid,lldp_delay):
        src_delay = self.RTT[src_dpid]
        dst_delay = self.RTT[dst_dpid]
        link_delay = lldp_delay - src_delay/2 - dst_delay/2
        return link_delay

    def update_graph_bandwidth(self):
        hub.sleep(10)
        print "Bandwidth Data Gathering Started"
        while True:
            t = self.calc_bw()
            hub.sleep(self.bw_time_interval-t)

    def calc_bw(self):
        init_time = time.time()
        links_list = self.topology.links
        port_data = {}
        bw_dict = {}
        d = {dp.id:{} for dp in self.dpdic.values()}
        
        for dp in self.dpdic.values():
            port_data[dp.id] = self.get_port_stats(dp)

        for link in links_list:
            src_dpid = link.src.dpid
            src_port_no = link.src.port_no
            tx_bytes = self.search(port_data[src_dpid],"port_no",src_port_no)["tx_bytes"]
            
            if self.tx_dict.get(src_dpid).get(src_port_no,None) == None:
                diff = tx_bytes
            else:
                diff = tx_bytes - self.tx_dict[src_dpid][src_port_no]
            
            bw = (8.0*diff) /(self.bw_time_interval * 10.0**6)
            link.bw = bw
            bw_dict[(link.src.dpid,link.dst.dpid)] = bw
            self.tx_dict[src_dpid][src_port_no]= tx_bytes
            self.net[src_dpid][link.dst.dpid]['bandwidth'] = bw
       
        #self.bwclient.send(" b" +str(bw_dict))
        try:
            requests.put("http://192.168.0.111:5000/bw",data={"bw":str(bw_dict)})
        except:
            print "Error in bw"
            pass
        return time.time() - init_time

    def search(self,list_, key, value): 
        for item in list_: 
            if item[key] == value: 
                return item

    def get_port_stats(self, datapath):
        self.logger.debug('send stats request: %016x', datapath.id)
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        req = parser.OFPPortStatsRequest(datapath, 0, ofproto.OFPP_ANY)
        lock = hub.Event()
        self.dplock[datapath.id] = lock
        datapath.send_msg(req)

        lock.wait(timeout=2)

        return self.port_data[datapath.id]

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply_handler(self, ev):
        body = ev.msg.body
        dpid = ev.msg.datapath.id
        self.port_data[dpid] = [item._asdict() for item in body]
        self.dplock[dpid].set()